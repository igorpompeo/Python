def ex001():
    print("Olá, Mundo!")
