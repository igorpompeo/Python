def ex005():
    # Faça um programa que leia um número inteiro
    # e mostre na tela o seu sucessor e seu antecessor.
    import random

    print("=== Desafio 05 ===")
    n = random.randint(1, 100)  # nosec
    print(f"O sucessor de {n} é {n + 1} e o antecessor é {n - 1}.")
    print("=== Fim do Desafio 05 ===")
    # Fim do desafio 05
